# Canzoni Coro v13

Progetto Android che incorpora la versione Chrome v13 di Canzoni Coro in una WebView.
Il workflow GitHub Actions compila automaticamente un APK debug.

Per creare l'APK: GitHub → Actions → Build Canzoni Coro APK → Run workflow.
