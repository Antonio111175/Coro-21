package com.canzonicoro.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.exifinterface.media.ExifInterface;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private String pickerSource = "gallery";
    private Uri pendingShareUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (pendingShareUri != null) {
                    Uri u = pendingShareUri;
                    pendingShareUri = null;
                    loadNativeImage(u, "whatsapp");
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");

        Intent in = getIntent();
        if (in != null && Intent.ACTION_SEND.equals(in.getAction())) {
            Uri uri = in.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri != null) pendingShareUri = uri;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void chooseGallery() {
            pickerSource = "gallery";
            openPicker();
        }
        @JavascriptInterface public void chooseWhatsApp() {
            pickerSource = "whatsapp";
            openPicker();
        }
        @JavascriptInterface public void enterFullscreen() { runOnUiThread(() -> webView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE)); }
        @JavascriptInterface public void exitFullscreen() { runOnUiThread(() -> webView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE)); }
        @JavascriptInterface public void appInfo() {
            runOnUiThread(() -> webView.evaluateJavascript("showAppInfo()", null));
        }
    }

    private void openPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, FILE_CHOOSER);
    }

    private void loadNativeImage(Uri uri, String source) {
        new Thread(() -> {
            try {
                String mime = getContentResolver().getType(uri);
                if (mime == null) mime = "image/jpeg";
                byte[] bytes = readBytes(uri);
                String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
                String dataUrl = "data:" + mime + ";base64," + b64;

                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                int width = opts.outWidth;
                int height = opts.outHeight;
                long fileSize = bytes.length;
                String exifDate = readExifDate(uri);
                long now = System.currentTimeMillis();

                String js = "receiveNativeImage(" + quote(dataUrl) + "," + quote(source) + "," +
                        quote(exifDate) + "," + width + "," + height + "," + fileSize + "," + now + ")";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            } catch (Exception e) {
                runOnUiThread(() -> webView.evaluateJavascript("nativeImageError()", null));
            }
        }).start();
    }

    private byte[] readBytes(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while (in != null && (n = in.read(buf)) != -1) out.write(buf, 0, n);
        if (in != null) in.close();
        return out.toByteArray();
    }

    private String readExifDate(Uri uri) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return "";
            ExifInterface exif = new ExifInterface(in);
            String date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
            if (date == null || date.isEmpty()) date = exif.getAttribute(ExifInterface.TAG_DATETIME);
            in.close();
            return date == null ? "" : date;
        } catch (Exception e) {
            return "";
        }
    }

    private String quote(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && resultCode == RESULT_OK && data != null && data.getData() != null) {
            loadNativeImage(data.getData(), pickerSource);
        }
    }
}
